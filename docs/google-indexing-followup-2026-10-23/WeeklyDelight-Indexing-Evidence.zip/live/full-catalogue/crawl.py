"""Read-only, bounded and paced audit of all intended canonical HTML URLs.

One normal GET per URL; no automatic retry of failures. Stops the complete run
on access/rate-limit challenges or an outage. Writes every intended URL,
including explicit unverified rows if a safety stop leaves URLs unrequested.
"""
from pathlib import Path
import collections
import concurrent.futures
import csv
import datetime
import gzip
import hashlib
import io
import json
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path('/workspace/Culinaryrecipie-indexing')
ARTIFACTS = Path('/workspace/artifacts/indexing-followup-2026-10-22')
OUT = ARTIFACTS / 'live/full-catalogue'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT / 'tools'))
from crawl_static import parse_html, summary

BASE = '9ebb8489fcd60909be13623c24b25a86b5dbd115'
USER_AGENT = 'WeeklyDelight-OwnerAudit/1.0 (read-only public technical review)'
manifest = json.loads((ARTIFACTS / 'static/manifest-current.json').read_text())
targets = sorted(manifest['routes'], key=lambda r: (r['type'] == 'recipe', r['url']))
assert len(targets) == 5871
assert len({r['url'] for r in targets}) == len(targets)

LOCK = threading.Lock()
NEXT_REQUEST = 0.0
STOP = threading.Event()
STOP_REASON = {}
FAILURE_STREAK = 0
NETWORK_REQUESTS = 0
BODY_SAVES = 0
JSONL = OUT / 'responses.jsonl'
STATS_PATH = OUT / 'stats.json'
START = datetime.datetime.now(datetime.timezone.utc).isoformat()

if STATS_PATH.exists() and json.loads(STATS_PATH.read_text()).get('stopped'):
    raise SystemExit('Prior run stopped for a real block/outage; no automatic resume. Preserve evidence and review the stop reason.')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def stop(reason):
    with LOCK:
        if not STOP.is_set():
            STOP_REASON.update(reason)
            STOP.set()
            print('STOP', json.dumps(reason), flush=True)


def pace():
    global NEXT_REQUEST, NETWORK_REQUESTS
    with LOCK:
        due = max(time.monotonic(), NEXT_REQUEST)
        NEXT_REQUEST = due + 0.205  # At most4.88newrequests/s, including redirect hops.
    time.sleep(max(0, due - time.monotonic()))
    if STOP.is_set():
        return False
    with LOCK:
        NETWORK_REQUESTS += 1
    return True


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


thread_local = threading.local()


def get_opener():
    if not hasattr(thread_local, 'opener'):
        thread_local.opener = urllib.request.build_opener(NoRedirect)
    return thread_local.opener


def update_failure_streak(bad, url, detail):
    global FAILURE_STREAK
    with LOCK:
        FAILURE_STREAK = FAILURE_STREAK + 1 if bad else 0
        should_stop = FAILURE_STREAK >= 3
    if should_stop:
        stop({
            'reason': 'Three consecutive completed requests had5xx/transport errors',
            'url': url, 'detail': detail, 'checked_at': now(),
        })


def save_selected_body(row, body):
    """Keep at most30diagnostic bodies, never thousands of complete pages."""
    global BODY_SAVES
    with LOCK:
        allowed = BODY_SAVES < 30
        if allowed:
            BODY_SAVES += 1
    if allowed:
        folder = OUT / 'selected-bodies'
        folder.mkdir(exist_ok=True)
        name = hashlib.sha256(row['url'].encode()).hexdigest()[:20] + '.html'
        file = folder / name
        file.write_bytes(body)
        row['body_file'] = str(file)


RELEVANT_HEADERS = {
    'date', 'content-type', 'content-encoding', 'location', 'server', 'platform',
    'panel', 'x-hcdn-request-id', 'x-hcdn-cache-status', 'x-hcdn-upstream-rt',
    'x-envoy-upstream-service-time', 'cache-control', 'retry-after',
    'x-robots-tag', 'www-authenticate', 'set-cookie', 'vary', 'last-modified', 'etag',
}


def request(target):
    url = target['url']
    row = {
        'url': url, 'page_type': target['type'], 'slug': target.get('slug'),
        'checked_at': now(), 'base_commit': BASE, 'method': 'GET',
        'hops': [], 'redirects': [], 'verified': False,
    }
    current = url
    seen = set()
    for _hop in range(5):
        if not pace():
            row['unverified'] = 'Run stopped before request: ' + str(STOP_REASON.get('reason'))
            return row
        started = time.monotonic()
        try:
            req = urllib.request.Request(current, headers={
                'User-Agent': USER_AGENT,
                'Accept-Encoding': 'gzip',
                'Accept': 'text/html,application/xhtml+xml,*/*;q=.8',
            })
            try:
                response = get_opener().open(req, timeout=30)
            except urllib.error.HTTPError as error:
                response = error
            with response as response:
                status = response.code
                headers = {k.lower(): v for k, v in response.headers.items()}
                body = response.read(3_000_001)
                if headers.get('content-encoding') == 'gzip':
                    body = gzip.GzipFile(fileobj=io.BytesIO(body)).read(3_000_001)
                relevant = {k: v for k, v in headers.items() if k in RELEVANT_HEADERS}
                row['hops'].append({
                    'url': current, 'status': status,
                    'elapsed_seconds': round(time.monotonic() - started, 3),
                    'bytes': len(body), 'headers': relevant,
                })
                row.update({
                    'status': status, 'final_url': current, 'verified': True,
                    'content_type': headers.get('content-type', ''),
                    'x_robots_tag': response.headers.get_all('X-Robots-Tag', []),
                    'headers': relevant, 'bytes': len(body),
                    'sha256': hashlib.sha256(body).hexdigest(),
                    'truncated': len(body) > 3_000_000,
                })
                text = body.decode('utf-8', errors='replace')
                if status in (403, 429):
                    stop({
                        'reason': f'HTTP{status}block/rate-limit; no retry or bypass',
                        'url': current, 'retry_after': headers.get('retry-after'),
                        'checked_at': now(),
                        'request_id': headers.get('x-hcdn-request-id'),
                        'body_excerpt': text[:1000],
                    })
                if status == 503 and 'envoy://cloudflare_https_tunnel/' in text:
                    row['environment_transport_error'] = True
                    stop({
                        'reason': 'Execution-environment transport failure',
                        'url': current, 'checked_at': now(), 'body_excerpt': text[:1000],
                    })
                update_failure_streak(status >= 500, current, str(status))
                if status in (301, 302, 303, 307, 308) and headers.get('location'):
                    destination = urllib.parse.urljoin(current, headers['location'])
                    row['redirects'].append({'url': current, 'status': status, 'to': destination})
                    seen.add(current)
                    if destination == current or destination in seen:
                        row['redirect_loop'] = True
                        row['failure'] = 'Redirect points to the same URL or an earlier hop'
                        row['body_excerpt'] = text[:500]
                        save_selected_body(row, body)
                        return row
                    if urllib.parse.urlsplit(destination).hostname not in ('weeklydelight.com', 'www.weeklydelight.com'):
                        row['failure'] = 'Unexpected external redirect destination'
                        row['redirect_destination'] = destination
                        return row
                    current = destination
                    continue
                if 'text/html' in row['content_type']:
                    page = parse_html(text)
                    detail = summary(page)
                    fields = (
                        'canonicals', 'meta_robots', 'title', 'h1', 'visible_chars',
                        'recipe_jsonld', 'recipe_microdata', 'recipe_rdfa',
                        'json_errors', 'challenge',
                    )
                    row.update({key: detail[key] for key in fields})
                    row['anchor_count'] = len(page.links)
                    if detail.get('challenge'):
                        stop({
                            'reason': 'Challenge/authentication-like page title; no bypass',
                            'url': current, 'checked_at': now(), 'title': detail.get('title'),
                        })
                    row['noindex'] = (
                        any(re.search(r'\bnoindex\b', x.get('content', ''), re.I) for x in row['meta_robots'])
                        or any(re.search(r'\bnoindex\b', x, re.I) for x in row['x_robots_tag'])
                    )
                    row['canonical_correct'] = row['canonicals'] == [url]
                    row['single_recipe_entity_correct'] = (
                        target['type'] != 'recipe'
                        or (row['recipe_jsonld'] == 1 and row['recipe_microdata'] == 0
                            and row['recipe_rdfa'] == 0 and not row['json_errors'])
                    )
                local_route = urllib.parse.urlsplit(current).path.lstrip('/')
                local_path = local_route + 'index.html' if not local_route or local_route.endswith('/') else local_route
                local_file = ROOT / local_path
                if local_file.is_file():
                    local = local_file.read_bytes()
                    row['current_main_sha256'] = hashlib.sha256(local).hexdigest()
                    row['byte_equal_current_main'] = local == body
                unusual = (
                    status != 200 or row.get('challenge') or row.get('noindex')
                    or row.get('canonical_correct') is False
                    or row.get('single_recipe_entity_correct') is False
                )
                if unusual:
                    save_selected_body(row, body)
                return row
        except Exception as error:
            row['transport_error'] = type(error).__name__ + ': ' + str(error)
            row['verified'] = bool(row['hops'])
            update_failure_streak(True, current, row['transport_error'])
            return row
    row['failure'] = 'Redirect chain exceeded five hops'
    return row


records = []
done = set()
if JSONL.exists():
    for line in JSONL.read_text().splitlines():
        # A malformed checkpoint is an audit-data error, never silently discarded.
        record = json.loads(line)
        assert record['url'] not in done, 'Duplicate checkpoint URL: ' + record['url']
        records.append(record)
        done.add(record['url'])
pending = [r for r in targets if r['url'] not in done]


def save_stats(final=False):
    status_counts = collections.Counter(str(r.get('status', 'unverified')) for r in records)
    out = {
        'started_at': START, 'updated_at': now(), 'base_commit': BASE,
        'total_intended_urls': len(targets), 'recorded_rows': len(records),
        'verified_http_rows': sum(bool(r.get('verified')) for r in records),
        'unverified_rows': sum(not r.get('verified') for r in records),
        'pending_rows': len(targets) - len(records),
        'network_requests_this_process': NETWORK_REQUESTS,
        'status_counts': dict(status_counts),
        'self_redirects': sum(bool(r.get('redirect_loop')) for r in records),
        'byte_equal_current_main': sum(r.get('byte_equal_current_main') is True for r in records),
        'byte_different_current_main': sum(r.get('byte_equal_current_main') is False for r in records),
        'noindex_200': sum(r.get('status') == 200 and bool(r.get('noindex')) for r in records),
        'wrong_canonical_200': sum(r.get('status') == 200 and r.get('canonical_correct') is False for r in records),
        'recipe_entity_failures_200': sum(r.get('status') == 200 and r.get('single_recipe_entity_correct') is False for r in records),
        'jsonld_errors_200': sum(r.get('status') == 200 and bool(r.get('json_errors')) for r in records),
        'stopped': STOP.is_set(), 'stop_reason': STOP_REASON, 'complete': final,
        'method': (
            'GETonly;4workers globally<=4.88newrequests/second including redirect hops;'
            'normalOwnerAuditUA,noauth/cookies/bypass;self307noautofollow/retry;'
            '403/429/challengestop;3consecutive5xx/transportstop'
        ),
        'limit': (
            'One observation per canonical URL does not prove continuous availability '
            'or Google indexing. Deployment bytes compared to checked-out9ebbmain.'
        ),
    }
    temporary = STATS_PATH.with_suffix('.tmp')
    temporary.write_text(json.dumps(out, indent=2) + '\n')
    temporary.replace(STATS_PATH)
    return out


def save_csv():
    fields = [
        'URL', 'page_type', 'HTTP_result', 'final_URL', 'redirect_chain',
        'canonical', 'robots', 'X-Robots-Tag', 'byte_equal_current_main',
        'Recipe_JSONLD', 'Recipe_microdata', 'Recipe_RDFa', 'visible_chars',
        'request_id', 'checked_at', 'remaining_issue',
    ]
    by_url = {r['url']: r for r in records}
    with (OUT / 'url-results.csv').open('w', newline='') as output:
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        for target in targets:
            row = by_url.get(target['url'], {})
            issue = row.get('unverified') or row.get('failure') or ''
            if row.get('status') != 200 and not issue:
                issue = 'HTTP' + str(row.get('status', 'unverified'))
            if row.get('noindex'):
                issue += ';noindex'
            if row.get('canonical_correct') is False:
                issue += ';wrong canonical'
            if row.get('single_recipe_entity_correct') is False:
                issue += ';Recipe entity problem'
            if row.get('byte_equal_current_main') is False:
                issue += ';HTML differs from current main'
            writer.writerow({
                'URL': target['url'], 'page_type': target['type'],
                'HTTP_result': row.get('status', 'Unverified'),
                'final_URL': row.get('final_url', ''),
                'redirect_chain': json.dumps(row.get('redirects', [])),
                'canonical': ' | '.join(row.get('canonicals', [])),
                'robots': ' | '.join(x.get('content', '') for x in row.get('meta_robots', [])),
                'X-Robots-Tag': ' | '.join(row.get('x_robots_tag', [])),
                'byte_equal_current_main': row.get('byte_equal_current_main', ''),
                'Recipe_JSONLD': row.get('recipe_jsonld', ''),
                'Recipe_microdata': row.get('recipe_microdata', ''),
                'Recipe_RDFa': row.get('recipe_rdfa', ''),
                'visible_chars': row.get('visible_chars', ''),
                'request_id': row.get('headers', {}).get('x-hcdn-request-id', ''),
                'checked_at': row.get('checked_at', ''),
                'remaining_issue': issue or 'Google indexing unknown; singleHTTPobservation only',
            })


print('START', len(pending), 'pending;', len(done), 'previous records;4workers max4.88requests/s', flush=True)
save_stats()
started = time.monotonic()
iterator = iter(pending)
with JSONL.open('a') as output, concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    futures = {}

    def add_next():
        if STOP.is_set():
            return
        try:
            target = next(iterator)
        except StopIteration:
            return
        futures[pool.submit(request, target)] = target

    for _ in range(4):
        add_next()
    while futures:
        finished, _ = concurrent.futures.wait(futures, return_when=concurrent.futures.FIRST_COMPLETED)
        for future in finished:
            target = futures.pop(future)
            try:
                row = future.result()
            except Exception as error:
                stop({'reason': 'Unexpected audit worker failure', 'detail': str(error), 'url': target['url']})
                row = {
                    'url': target['url'], 'page_type': target['type'], 'verified': False,
                    'unverified': str(error), 'checked_at': now(),
                }
            records.append(row)
            done.add(row['url'])
            output.write(json.dumps(row, ensure_ascii=False) + '\n')
            output.flush()
            if len(records) % 100 == 0:
                stats = save_stats()
                print('PROGRESS', len(records), '/', len(targets), 'elapsed',
                      round(time.monotonic() - started), 's', 'status',
                      stats['status_counts'], 'loops', stats['self_redirects'], flush=True)
            add_next()
    if STOP.is_set():
        for target in targets:
            if target['url'] in done:
                continue
            row = {
                'url': target['url'], 'page_type': target['type'], 'slug': target.get('slug'),
                'base_commit': BASE, 'verified': False, 'checked_at': now(),
                'unverified': 'Not requested: ' + str(STOP_REASON.get('reason')),
            }
            records.append(row)
            done.add(target['url'])
            output.write(json.dumps(row, ensure_ascii=False) + '\n')

stats = save_stats(final=True)
save_csv()
print('FINAL', json.dumps(stats), flush=True)
