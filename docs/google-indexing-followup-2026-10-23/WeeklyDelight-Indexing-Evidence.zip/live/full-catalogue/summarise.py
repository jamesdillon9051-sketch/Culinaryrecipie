"""Summarise the completed live snapshot and join its URL rows with static evidence."""
from pathlib import Path
import collections
import csv
import datetime
import json

P = Path('/workspace/artifacts/indexing-followup-2026-10-22')
OUT = P / 'live/full-catalogue'
stats = json.loads((OUT / 'stats.json').read_text())
assert stats['complete'], 'Wait for the live audit to finish before finalising.'
records = [json.loads(line) for line in (OUT / 'responses.jsonl').read_text().splitlines()]
# Retain network-level observations unchanged; qualify production-origin verification.
stats['verified_origin_http_rows'] = sum(bool(r.get('verified')) and not r.get('environment_transport_error') for r in records)
stats['origin_unverified_rows'] = len(records) - stats['verified_origin_http_rows']
stats['environment_transport_failures'] = sum(bool(r.get('environment_transport_error')) for r in records)
stats['byte_different_origin_html'] = sum(r.get('byte_equal_current_main') is False and not r.get('environment_transport_error') for r in records)
stats['run_finished'] = True
stats['complete_origin_live_coverage'] = stats['origin_unverified_rows'] == 0
stats['origin_status_counts'] = dict(collections.Counter(str(r['status']) for r in records if r.get('verified') and not r.get('environment_transport_error')))
control_path = P / 'live/recovery-control.json'
recovery_control = json.loads(control_path.read_text()) if control_path.exists() else None
(OUT / 'stats.json').write_text(json.dumps(stats, indent=2) + '\n')
manifest = json.loads((P / 'static/manifest-current.json').read_text())
expected = {row['url']: row for row in manifest['routes']}
actual = {row['url']: row for row in records}
assert len(records) == len(actual) == len(expected) == 5871
assert set(actual) == set(expected)

by_type = {}
for kind in sorted({row['type'] for row in expected.values()}):
    items = [row for row in records if row['page_type'] == kind]
    by_type[kind] = {
        'expected': sum(row['type'] == kind for row in expected.values()),
        'rows': len(items),
        'HTTP_statuses': dict(collections.Counter(str(row.get('status', 'unverified')) for row in items)),
        'unverified_origin': sum(not row.get('verified') or bool(row.get('environment_transport_error')) for row in items),
        'byte_equal_current_main': sum(row.get('byte_equal_current_main') is True for row in items),
        'self_redirects': sum(bool(row.get('redirect_loop')) for row in items),
    }

by_layout = {}
for layout in sorted({row.get('layout', 'unspecified') for row in expected.values() if row['type'] == 'recipe'}):
    items = [actual[url] for url, target in expected.items() if target['type'] == 'recipe' and target.get('layout', 'unspecified') == layout]
    by_layout[layout] = {
        'recipes': len(items), 'HTTP200': sum(row.get('status') == 200 for row in items),
        'one_primary_Recipe_no_extra_markup': sum(row.get('single_recipe_entity_correct') is True for row in items),
    }

issues = []
for row in records:
    reasons = []
    if not row.get('verified'):
        reasons.append(row.get('unverified', 'Unverified'))
    if row.get('environment_transport_error'):
        reasons.append('Execution proxy transport failure; production origin HTTP result unverified')
    elif row.get('status') != 200:
        reasons.append('HTTP' + str(row.get('status', 'unverified')))
    if row.get('redirect_loop'):
        reasons.append('Self-redirect loop')
    if row.get('redirects'):
        reasons.append('Canonical target required a redirect')
    if row.get('byte_equal_current_main') is False and not row.get('environment_transport_error'):
        reasons.append('HTML bytes differ from checked-out base')
    if row.get('noindex'):
        reasons.append('noindex on intended indexable URL')
    if row.get('canonical_correct') is False:
        reasons.append('Canonical differs from intended URL')
    if row.get('single_recipe_entity_correct') is False:
        reasons.append('Recipe entity count/markup mismatch')
    if row.get('json_errors'):
        reasons.append('JSON-LD parse error')
    if row.get('challenge'):
        reasons.append('Challenge-like title')
    if row.get('truncated'):
        reasons.append('Body exceeded3MBbound')
    target = expected[row['url']]
    if target['type'] == 'recipe' and row.get('status') == 200 and row.get('h1') != target.get('title'):
        reasons.append('RecipeH1differs from source title')
    if reasons:
        issues.append({'URL': row['url'], 'page_type': row['page_type'], 'issues': reasons})

report = {
    'summarised_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'base_commit': stats['base_commit'], 'started_at': stats['started_at'],
    'finished_at': stats['updated_at'], 'stats': stats,
    'by_page_type': by_type, 'by_recipe_layout': by_layout,
    'review_or_unverified_row_count': len(issues), 'review_or_unverified_rows': issues,
    'unverified_production_url_count': stats['origin_unverified_rows'],
    'confirmed_origin_issue_count': sum(
        not actual[r['URL']].get('environment_transport_error') and actual[r['URL']].get('verified')
        for r in issues
    ),
    'recovery_control': recovery_control,
    'claim_limit': (
        'Full intended-catalogue inventory with partial live verification; not a complete live crawl or Google indexing report. '
        'Original HTML/schema only; browser-injected markup tested separately. '
        'CleanOct23requests do not erase the saved intermittentOct22self307observations, '
        'nor establish that a repository edit fixed hosting.'
    ),
}
(OUT / 'summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

with (P / 'static/url-level-static-audit.csv').open(newline='') as input_file:
    static_rows = list(csv.DictReader(input_file))
assert {row['URL'] for row in static_rows} == set(expected)
fields = list(static_rows[0])
with (OUT / 'combined-url-audit.csv').open('w', newline='') as output:
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    for original in static_rows:
        row = dict(original)
        live = actual[row['URL']]
        if live.get('environment_transport_error'):
            row['HTTP result'] = 'Unverified production origin: execution proxy503transport error; not a confirmed website503'
        elif not live.get('verified'):
            row['HTTP result'] = 'Unverified: ' + live.get('unverified', 'No successful HTTP observation')
        else:
            row['HTTP result'] = str(live.get('status'))
            if live.get('redirect_loop'):
                row['HTTP result'] += ' self-redirect loop'
            elif live.get('redirects'):
                row['HTTP result'] += ' after ' + str(len(live['redirects'])) + ' redirect(s)'
            row['HTTP result'] += '; checked ' + live.get('checked_at', '')
        if live.get('canonicals'):
            row['canonical'] = ' | '.join(live['canonicals'])
        else:
            row['canonical'] = 'Static: ' + original['canonical'] + '; live HTML unavailable'
        if live.get('status') == 200 and 'meta_robots' in live:
            meta = ' | '.join(x.get('name', '') + ':' + x.get('content', '') for x in live['meta_robots'])
            header = ' | '.join(live.get('x_robots_tag', [])) or '(absent)'
            row['robots/indexability result'] = 'LiveHTML: ' + meta + '; X-Robots-Tag: ' + header + '; ' + original['robots/indexability result'].replace('; live headers unverified', '')
        else:
            row['robots/indexability result'] = 'Live directives unverified for this response; ' + original['robots/indexability result']
        if live.get('status') == 200 and 'recipe_jsonld' in live:
            row['structured-data issues'] = (
                'Original liveHTML: RecipeJSON-LD=' + str(live['recipe_jsonld'])
                + ', Recipe microdata=' + str(live['recipe_microdata'])
                + ', RecipeRDFa=' + str(live['recipe_rdfa']) + '; '
                + original['structured-data issues']
            )
        row['action taken'] = original['action taken'] + '; read-only productionGET snapshot against base ' + stats['base_commit'][:9]
        row['remaining issue'] = 'Indexing status unknown beyond supplied historical evidence; one HTTPsnapshot does not establish uninterrupted access or Google indexing.'
        if live.get('environment_transport_error'):
            row['remaining issue'] += ' Execution network transport failure prevented origin verification; no recipe or deployment defect established.'
        elif live.get('status') != 200 or not live.get('verified'):
            row['remaining issue'] += ' Live access problem/unverified: ' + (live.get('failure') or live.get('unverified') or str(live.get('status')))
        writer.writerow(row)

lines = [
    '# Full catalogue inventory with partial live HTTP verification', '',
    f"Checked {stats['started_at']} through {stats['updated_at']} against `{stats['base_commit']}`.", '',
    f"All **{len(records):,} intended canonical URLs** have a URL-level result: "
    f"{stats['verified_origin_http_rows']:,} verified origin HTTP observations and {stats['origin_unverified_rows']:,} production-origin unverified rows (including execution-proxy failure).", '',
    '| Page type | Expected | HTTP outcomes | HTML byte-equal to base |',
    '| --- | ---: | --- | ---: |',
]
for kind, value in by_type.items():
    outcomes = ', '.join(k + ': ' + str(v) for k, v in value['HTTP_statuses'].items())
    lines.append(f"| {kind} | {value['expected']} | {outcomes} | {value['byte_equal_current_main']} |")
lines.extend([
    '', f"Self-redirects: {stats['self_redirects']}. noindex200pages: {stats['noindex_200']}. Wrong canonical200pages: {stats['wrong_canonical_200']}. Recipe entity failures: {stats['recipe_entity_failures_200']}. JSON-LD parse errors: {stats['jsonld_errors_200']}.",
    '', f"Production-origin unverified rows: {stats['origin_unverified_rows']:,}. Confirmed origin defects in the successfully fetched pages: {report['confirmed_origin_issue_count']}. Unverified URLs are not labelled broken or unindexed; see `summary.json` for exact coverage.", '',
    'The execution proxy returned one503transport error containing `envoy://cloudflare_https_tunnel/`. It is not a confirmed website503, stale page or recipe defect. The run stopped immediately and did not retry; remaining URLs are explicitly unrequested. Network response counts retain that proxy503separately from verified origin responses.', '',
    ('A separate single normal robots.txt recovery control at ' + recovery_control['checked_at'] + ' also returned the same execution-proxy tunnel error. The environment status was connected/unrestricted, but the actual network operation remained blocked. No further site requests or catalogue resume were attempted.' if recovery_control else 'No post-stop recovery control was available.'), '',
    'Method:4workers, globally at most4.88newGETrequests/second including redirect hops; normal public owner-auditUser-Agent; TLS and proxy retained; no cookies/authentication/Googlebotspoofing. Self-redirects are not followed/retried. Access/rate-limit/challenge responses or a sustained transport outage stop the complete run.', '',
    'These results are **technical access observations**, not evidence that Google indexed a URL. Compare the separately savedOct22intermittent307observations with the currentOct23snapshot without erasing either. No deployment or hosting change was performed by this audit.', '',
    'Files: `responses.jsonl` (every observed/unverifiedURL), `url-results.csv` (HTTPdetails), `combined-url-audit.csv` (the required full static/live/GSC-evidence table), `stats.json`, `summary.json`, and `run.log`.', '',
])
(OUT / 'README.md').write_text('\n'.join(lines))
print(json.dumps({'rows': len(records), 'status_counts': stats['status_counts'], 'issues': len(issues), 'by_page_type': by_type}, indent=2))
