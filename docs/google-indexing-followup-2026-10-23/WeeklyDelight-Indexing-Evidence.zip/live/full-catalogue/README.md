# Full catalogue inventory with partial live HTTP verification

Checked 2026-10-23T03:27:44.770604+00:00 through 2026-10-23T03:31:54.664235+00:00 against `9ebb8489fcd60909be13623c24b25a86b5dbd115`.

All **5,871 intended canonical URLs** have a URL-level result: 1,216 verified origin HTTP observations and 4,655 production-origin unverified rows (including execution-proxy failure).

| Page type | Expected | HTTP outcomes | HTML byte-equal to base |
| --- | ---: | --- | ---: |
| category | 10 | 200: 10 | 10 |
| category-combination | 193 | 200: 193 | 193 |
| cuisine | 92 | 200: 92 | 92 |
| ingredient | 51 | 200: 51 | 51 |
| other | 10 | 200: 10 | 10 |
| recipe | 5515 | 200: 860, 503: 1, unverified: 4654 | 860 |

Self-redirects: 0. noindex200pages: 0. Wrong canonical200pages: 0. Recipe entity failures: 0. JSON-LD parse errors: 0.

Production-origin unverified rows: 4,655. Confirmed origin defects in the successfully fetched pages: 0. Unverified URLs are not labelled broken or unindexed; see `summary.json` for exact coverage.

The execution proxy returned one503transport error containing `envoy://cloudflare_https_tunnel/`. It is not a confirmed website503, stale page or recipe defect. The run stopped immediately and did not retry; remaining URLs are explicitly unrequested. Network response counts retain that proxy503separately from verified origin responses.

A separate single normal robots.txt recovery control at 2026-10-23T03:36:16.340761+00:00 also returned the same execution-proxy tunnel error. The environment status was connected/unrestricted, but the actual network operation remained blocked. No further site requests or catalogue resume were attempted.

Method:4workers, globally at most4.88newGETrequests/second including redirect hops; normal public owner-auditUser-Agent; TLS and proxy retained; no cookies/authentication/Googlebotspoofing. Self-redirects are not followed/retried. Access/rate-limit/challenge responses or a sustained transport outage stop the complete run.

These results are **technical access observations**, not evidence that Google indexed a URL. Compare the separately savedOct22intermittent307observations with the currentOct23snapshot without erasing either. No deployment or hosting change was performed by this audit.

Files: `responses.jsonl` (every observed/unverifiedURL), `url-results.csv` (HTTPdetails), `combined-url-audit.csv` (the required full static/live/GSC-evidence table), `stats.json`, `summary.json`, and `run.log`.
