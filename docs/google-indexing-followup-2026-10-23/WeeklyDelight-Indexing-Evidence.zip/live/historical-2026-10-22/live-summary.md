# Live technical audit — 22 October 2026

Current repository reference: `9ebb8489fcd60909be13623c24b25a86b5dbd115`. Read-only observations: 2026-10-22T20:37:13.617748+00:00.

**Confirmed reliability issue:** normal public requests intermittently received `307 Temporary Redirect` with `Location` resolving to the exact same URL, including preferred `robots.txt`, `/sitemap.xml`, child sitemaps2/10, `/recipes/` and `/categories/baking/italian/`. Initial and subsequent observations are preserved, including successful200 responses. Plain HTTPwww deep URLs repeatedly self-redirected. This can prevent a fetch for the affected request; it is not proof of Google's specific historical cause or a catalogue-wide indexing verdict.

The saved307body is164bytes of plain nginx Temporary Redirect HTML. It has **no JavaScript/CAPTCHA, Set-Cookie, Retry-After or WWW-Authenticate**. Headers contain HostingerHCDNrequest IDs and an `envoy` server marker. Successful responses additionally contain Hostinger/hPanel/cache metadata. Repository `.htaccess` uses301canonical redirects and contains no307rule. HTTP1.1/HTTP2 comparisons both reproduced307, then another normal client fetched200 seconds later. External evidence does not locate the exact generator: HCDN, an upstream component or an intermediary requires request/server logs. No cookie, UA, WAF or proxy bypass was used.

## Successful checks and limits

- All12child sitemaps were fetched successfully at least once and are well-formed XML, byte-equal to currentmain, with **5,871 unique URL entries**, no duplicates and all preferredHTTPSapex URLs. Both index paths are valid on successful requests. This confirms sitemap contents, not uninterrupted accessibility.
- Live robots.txt200body is byte-equal to repository and declares `https://weeklydelight.com/sitemap-index.xml`; its earlier307and later307recurrence remain unresolved.
- The baked-peaches page returns200, matches currentmain bytes, has the expected preferred canonical, index/follow metadata, no X-Robots-Tag and **one RecipeJSON-LD, zero Recipe microdata, zero RecipeRDFa** in original source. Its six ingredients/four instructions/yield/timing/author/image appear in the saved parsed record. No duplicate incomplete Recipe entity was reproduced in original HTML. Rendered DOM/third-party execution requires separate browser review.
- Preferred homepage, recipe/category/cuisine/navigation/info examples returned substantive200HTML matching main. Search landing `/search/` currently has index/follow; `/favourites/` has noindex/follow. No recommendation to bulk noindex category/recipe pages is made here.
- Both deliberately nonexistent page/recipe URLs correctly returned404 and noindex/follow, not empty200templates. Direct `/404.html` is a200noindex error-template asset, distinct from missing routes returning404.
- HTTPapex and successfulHTTPSwww probes301to the preferred apex and preserve paths. Bare recipe path, explicit `index.html` and homepage `index.html`301to the expected trailing-slash canonical. Somewww probes also showed307self-redirects, so do not declare hostname consistency fully reliable.
- All10declared image examples returned200and decoded correctly; nine recipe/process photos are800×600, icon192×192. CDN responds with validWebP even on someJPG/PNGpaths when the request acceptsWebP. Image-byte differences alone are not stale-deployment proof. No missing-image generation was performed.
- No observed403,429,5xx, authentication challenge or X-Robots-Tag header in this sample. This statement covers the sample only.

## Next action

Ask the hosting/integration owner to inspect HostingerCDN/edge/redirect/security and upstream logs for the exact saved UTCtimes and `x-hcdn-request-id` values. Determine why some normal requests get a relative307to themselves before claiming it fixed. Do not repeatedly delete/resubmit sitemaps. Recheck robots, both index paths, all12children, canonical pages andwwwdeep variants after a reviewed hosting change. Repository `.htaccess` edits alone do not prove a HostingerCDNlayer change or live repair.

There are61unique targets and80request observations in this bounded audit, plus redirect hops. **The full catalogue was not fetched live. No URL is labelled indexed.** The screenshots/CSVhistorical evidence, local source/static checks, these live observations and actual Google indexing remain separate evidence.

Artifacts: `responses.json` retains initial observations; `redirect-confirmation.json` and `protocol-comparison.json` retain independent follow-ups; `observations.json` combines them; `url-results.csv` provides one row per requestedURL; `summary.json` contains current counts; raw headers/bodies are saved in sibling folders.
