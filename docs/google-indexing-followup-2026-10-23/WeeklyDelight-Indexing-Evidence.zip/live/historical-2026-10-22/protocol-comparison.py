from pathlib import Path
import urllib.request,urllib.error,json,subprocess,time,datetime,hashlib
p=Path('/workspace/artifacts/indexing-followup-2026-10-22/live');folder=p/'protocol-comparison';folder.mkdir(exist_ok=True)
UA='WeeklyDelight-OwnerAudit/1.0 (read-only public technical review)'
# Repeat normal public requests in fixed order. No cache busting, cookies, proxy changes or altered UA.
urls=['https://weeklydelight.com/robots.txt','https://weeklydelight.com/sitemap-2.xml','https://weeklydelight.com/recipes/']
results=[]
for n,url in enumerate(urls):
 for variant in['curlHTTP1gzip','curlHTTP2gzip','urllibHTTP1gzip']:
  time.sleep(1.1);key=hashlib.sha256((variant+url).encode()).hexdigest()[:16];file=folder/(key+'.body');headers=folder/(key+'.headers');row={'url':url,'variant':variant,'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};start=time.monotonic()
  if variant.startswith('curl'):
   cmd=['curl','--silent','--show-error','--max-time','30','--max-redirs','0','--compressed','--http1.1'if'HTTP1'in variant else'--http2','--user-agent',UA,'--header','Accept-Encoding: gzip','--header','Accept: text/html,application/xml,text/plain,*/*;q=.8','--dump-header',str(headers),'--output',str(file),'--write-out','%{json}',url]
   r=subprocess.run(cmd,capture_output=True,text=True);row['exit_code']=r.returncode;row['stderr']=r.stderr
   try:row['curl']=json.loads(r.stdout);row['status']=row['curl']['http_code']
   except:row['curl_raw']=r.stdout
   if headers.exists():row['raw_headers']=headers.read_text()
  else:
   class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kw):return None
   try:
    req=urllib.request.Request(url,headers={'User-Agent':UA,'Accept-Encoding':'gzip','Accept':'text/html,application/xml,text/plain,*/*;q=.8'})
    try:r=urllib.request.build_opener(NoRedirect).open(req,timeout=30)
    except urllib.error.HTTPError as e:r=e
    with r:row['status']=r.code;row['raw_headers']=str(r.headers);b=r.read(2_000_000);file.write_bytes(b);headers.write_text(row['raw_headers']);row['response_http_version']=r.version
   except Exception as e:row['transport_error']=str(e)
  row['elapsed_seconds']=round(time.monotonic()-start,3);row['body_file']=str(file);row['headers_file']=str(headers)
  if file.exists():b=file.read_bytes();row['bytes']=len(b);row['sha256']=hashlib.sha256(b).hexdigest();row['body_excerpt']=b.decode('utf8',errors='replace')[:500]if row.get('status')!=200 else None
  results.append(row);(p/'protocol-comparison.json').write_text(json.dumps(results,indent=2)+'\n');print(row.get('status'),variant,url,flush=True)
