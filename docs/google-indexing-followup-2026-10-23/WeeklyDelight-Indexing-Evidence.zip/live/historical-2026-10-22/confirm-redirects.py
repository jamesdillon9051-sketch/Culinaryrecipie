from pathlib import Path
import subprocess,json,time,hashlib,concurrent.futures,threading,re,datetime
p=Path('/workspace/artifacts/indexing-followup-2026-10-22/live');folder=p/'redirect-confirmation';folder.mkdir(exist_ok=True);rows=json.load(open(p/'responses.json'));targets=[r['url']for r in rows if r.get('redirect_loop')];lock=threading.Lock();nxt=0
UA='WeeklyDelight-OwnerAudit/1.0 (read-only public technical review)'
def work(url):
 global nxt
 with lock:due=max(time.monotonic(),nxt);nxt=due+1.2
 time.sleep(max(0,due-time.monotonic()));key=hashlib.sha256(url.encode()).hexdigest()[:16];head=folder/(key+'.headers.txt');body=folder/(key+'.body.html')
 start=time.monotonic();r=subprocess.run(['curl','--silent','--show-error','--max-time','35','--max-redirs','0','--compressed','--user-agent',UA,'--header','Accept: text/html,application/xml,text/plain,*/*;q=.8','--dump-header',str(head),'--output',str(body),'--write-out','%{json}',url],capture_output=True,text=True)
 o={'url':url,'client':'curl normalGET same owner-audit User-Agent; no-follow, no cookies','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':round(time.monotonic()-start,3),'exit_code':r.returncode,'stderr':r.stderr,'headers_file':str(head),'body_file':str(body)}
 try:o['curl']=json.loads(r.stdout)
 except:o['curl_raw']=r.stdout
 if head.exists():o['raw_headers']=head.read_text()
 if body.exists():b=body.read_bytes();o.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),body_excerpt=b.decode('utf8',errors='replace')[:3500])
 print(o.get('curl',{}).get('http_code'),url,o.get('curl',{}).get('redirect_url'),flush=True);return o
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:out=list(pool.map(work,targets))
(p/'redirect-confirmation.json').write_text(json.dumps(out,indent=2)+'\n')
