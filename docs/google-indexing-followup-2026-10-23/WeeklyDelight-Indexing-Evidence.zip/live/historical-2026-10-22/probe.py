"""Bounded owner-authorised read-only live probe; no authentication, cookies or browser actions."""
from pathlib import Path
import urllib.request,urllib.error,urllib.parse,datetime,json,time,threading,concurrent.futures,hashlib,gzip,re,sys,xml.etree.ElementTree as ET
ROOT=Path('/workspace/Culinaryrecipie-indexing');OUT=Path('/workspace/artifacts/indexing-followup-2026-10-22/live');(OUT/'bodies').mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'tools'));from crawl_static import parse_html,summary,is_recipe
LOCK=threading.Lock();NEXT=0;STOPPED={};TRANSPORT_STOP=False;RESULTS=[]
NS={'s':'http://www.sitemaps.org/schemas/sitemap/0.9'};PREFERRED='https://weeklydelight.com'
UA='WeeklyDelight-OwnerAudit/1.0 (read-only public technical review)'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pace():
 global NEXT
 with LOCK:due=max(time.monotonic(),NEXT);NEXT=due+.60
 time.sleep(max(0,due-time.monotonic()))
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect)
def origin(url):
 u=urllib.parse.urlsplit(url);return u.scheme+'://'+u.netloc

def get(target):
 global TRANSPORT_STOP
 url,kind=target;row={'url':url,'kind':kind,'method':'GET','checked_at':now(),'redirects':[],'user_agent':UA};current=url
 for hop in range(8):
  if TRANSPORT_STOP:row['unverified']='Stopped after execution-environment transport failure';return row
  if origin(current)in STOPPED:row['unverified']='No retry or bypass: earlier403/429/503/challenge stopped this origin';row['stop_evidence']=STOPPED[origin(current)];return row
  pace();started=time.monotonic()
  try:
   request=urllib.request.Request(current,headers={'User-Agent':UA,'Accept-Encoding':'gzip','Accept':'image/avif,image/webp,image/*,*/*;q=.8'if kind=='image'else'text/html,application/xml,text/plain,*/*;q=.8'})
   try:r=opener.open(request,timeout=35)
   except urllib.error.HTTPError as e:r=e
   with r:
    status=r.code;headers={k.lower():v for k,v in r.headers.items()};body=r.read(4_000_001)
    if headers.get('content-encoding')=='gzip':body=gzip.decompress(body)
    row['hops']=row.get('hops',[])+[{'url':current,'status':status,'headers':headers,'elapsed_seconds':round(time.monotonic()-started,3),'bytes':len(body)}]
    if status in [301,302,303,307,308]and headers.get('location'):
     dest=urllib.parse.urljoin(current,headers['location']);row['redirects'].append({'url':current,'status':status,'to':dest});current=dest
     if current in [x['url']for x in row['redirects']]:row['redirect_loop']=True;break
     continue
    row.update(status=status,final_url=current,content_type=headers.get('content-type',''),x_robots_tag=r.headers.get_all('X-Robots-Tag',[]),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),headers=headers)
    ident=hashlib.sha256(url.encode()).hexdigest()[:16];ext='.jpg'if'image/jpeg'in row['content_type']else'.webp'if'image/webp'in row['content_type']else'.xml'if kind=='sitemap'else'.txt'if kind=='robots'else'.html';saved=OUT/'bodies'/(ident+ext);saved.write_bytes(body);row['body_file']=str(saved)
    if len(body)>4_000_000:row['truncated']=True
    text=body.decode('utf-8',errors='replace')if kind!='image'else''
    if status==503 and'envoy://cloudflare_https_tunnel/'in text:row['environment_transport_error']=text[:4000];TRANSPORT_STOP=True
    if status in[403,429,503]:
     STOPPED[origin(current)]={'url':current,'status':status,'retry_after':headers.get('retry-after'),'body_excerpt':text[:1000]};row['no_automatic_retry']=True
    if kind not in['image','sitemap','robots']and'text/html'in row['content_type']:
     parsed=parse_html(text);row.update(summary(parsed));row['anchor_count']=len(parsed.links);row['schema_types']=[e.get('@type')for e in parsed.schema];row['primary_recipe_details']=[{k:e.get(k)for k in['name','recipeIngredient','recipeInstructions','recipeYield','author','prepTime','cookTime','totalTime','image','datePublished','dateModified']}for e in parsed.schema if is_recipe(e.get('@type',''))]
     if row.get('challenge'):STOPPED[origin(current)]={'url':current,'status':status,'reason':'Challenge-like HTML title'}
    if kind=='sitemap':
     try:
      el=ET.fromstring(body);row['xml_root']=el.tag;row['xml_valid']=True;row['sitemap_urls']=[x.text for x in el.findall('s:sitemap/s:loc',NS)];row['page_urls']=[x.text for x in el.findall('s:url/s:loc',NS)];row['lastmods']=[x.text for x in el.findall('.//s:lastmod',NS)];row['image_urls']=[x.text for x in el.findall('.//{http://www.google.com/schemas/sitemap-image/1.1}loc')];row['duplicate_entries']=len(row['page_urls'])-len(set(row['page_urls']));row['nonpreferred_page_urls']=[x for x in row['page_urls']if not x.startswith(PREFERRED+'/')];row['nonpreferred_image_urls']=[x for x in row['image_urls']if not x.startswith(PREFERRED+'/')]
     except Exception as e:row['xml_valid']=False;row['xml_error']=str(e)
    # Compare final destination bytes to exact checked-out currentmain output.
    dest=urllib.parse.urlsplit(current)
    if dest.hostname in['weeklydelight.com','www.weeklydelight.com']:
     route=urllib.parse.unquote(dest.path).lstrip('/');file=ROOT/(route+'index.html'if not route or route.endswith('/')else route)
     if file.is_file():row['repository_path']=str(file.relative_to(ROOT));local=file.read_bytes();row['current_main_sha256']=hashlib.sha256(local).hexdigest();row['byte_equal_current_main']=body==local
    if kind=='robots':row['sitemap_declarations']=re.findall(r'^Sitemap:\s*(\S+)',text,re.M|re.I);row['body']=text
    if kind=='image':
     row['image_signature']=body[:16].hex();row['expected_image_content_type']=row['content_type'].startswith('image/')
    return row
  except Exception as e:row.update(final_url=current,transport_error=type(e).__name__+': '+str(e));return row
 row['unverified']='Redirect limit or loop';return row

def batch(targets):
 # Executor.map preserves target ordering while at most2requests overlap.
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
  for row in pool.map(get,targets):
   RESULTS.append(row);print(row.get('status','UNVERIFIED'),row['kind'],row['url'],'=>',row.get('final_url',''),flush=True)
   (OUT/'responses.json').write_text(json.dumps(RESULTS,ensure_ascii=False,indent=2)+'\n')

core=[(PREFERRED+'/robots.txt','robots'),(PREFERRED+'/sitemap-index.xml','sitemap'),(PREFERRED+'/sitemap.xml','sitemap'),(PREFERRED+'/','page'),(PREFERRED+'/recipes/baked-peaches-with-cinnamon/','page')]
batch(core)
childs=sorted(set(u for r in RESULTS for u in r.get('sitemap_urls',[])))
if not childs:childs=[PREFERRED+'/'+f.name for f in sorted(ROOT.glob('sitemap-[0-9]*.xml'))]
batch([(u,'sitemap')for u in childs if u.startswith(PREFERRED+'/')])
# Fixed representative HTML template, source correction, navigation and error examples.
paths=['/recipes/','/categories/','/categories/dinner/','/categories/baking/italian/','/categories/drinks/','/cuisines/','/cuisines/italian/','/search/','/favourites/','/about/','/contact/','/recipes/churro-waffles/','/recipes/huhnersuppe-mit-nudeln/','/recipes/ham-and-cheese-sliders/','/recipes/instant-pot-beef-brisket/','/recipes/korean-beef-lettuce-wraps/','/recipes/bounty-slice/','/recipes/painkiller/','/recipes/egyptian-rice-with-vermicelli/','/no-such-page-owner-audit-20261022/','/recipes/no-such-recipe-owner-audit-20261022/','/404.html']
batch([(PREFERRED+u,'page')for u in paths])
variants=[]
for schemehost in['http://weeklydelight.com','http://www.weeklydelight.com','https://www.weeklydelight.com']:
 for route in['/','/recipes/baked-peaches-with-cinnamon/','/categories/baking/italian/']:variants.append((schemehost+route,'hostname_probe'))
variants +=[(PREFERRED+'/recipes/baked-peaches-with-cinnamon','alternate_path'),(PREFERRED+'/recipes/baked-peaches-with-cinnamon/index.html','alternate_path'),(PREFERRED+'/index.html','alternate_path')]
batch(variants)
images=set()
for row in RESULTS:
 if row['url']==PREFERRED+'/recipes/baked-peaches-with-cinnamon/':
  for recipe in row.get('primary_recipe_details',[]):
   for image in recipe.get('image')or[]:
    if isinstance(image,dict):images.add(image.get('url')or image.get('contentUrl'))
    elif isinstance(image,str):images.add(image)
for slug in['churro-waffles','huhnersuppe-mit-nudeln','egyptian-rice-with-vermicelli']:
 for ext in['jpg','webp']:images.add(PREFERRED+'/assets/img/recipes/'+slug+'.'+ext)
images.update([PREFERRED+'/assets/img/recipes/ham-and-cheese-sliders-process.webp',PREFERRED+'/assets/img/recipes/instant-pot-beef-brisket-process.webp',PREFERRED+'/assets/img/icon-192.png'])
batch([(u,'image')for u in sorted(images)if u])
xml=[r for r in RESULTS if r['kind']=='sitemap'];childrows=[r for r in xml if r.get('xml_root','').endswith('urlset')];allurls=[u for r in childrows for u in r.get('page_urls',[])];childdeclared=set(childs)
report={'checked_at':now(),'current_main':'9ebb8489fcd60909be13623c24b25a86b5dbd115','method':'Normal public owner-audit User-Agent; GET only;2workers;globally paced one new request per0.60second including redirects; no cookies/authentication; no403retry;429/503 stops with Retry-After recorded. TLS and environment proxy preserved.','scope_limit':'Representative HTTP sample plus every declared child sitemap, not every live catalogueURL. These results do not establish Google indexing or verified Googlebot access.','requested_targets':len(RESULTS),'verified_status_counts':{},'current_main_byte_equal':sum(r.get('byte_equal_current_main')is True for r in RESULTS),'current_main_byte_different':sum(r.get('byte_equal_current_main')is False for r in RESULTS),'stopped_origins':STOPPED,'environment_transport_stop':TRANSPORT_STOP,'sitemaps':{'declared_children':len(childdeclared),'children_successful_xml':sum(r.get('status')==200 and r.get('xml_valid')and r['url']in childdeclared for r in xml),'url_entries':len(allurls),'unique_url_entries':len(set(allurls)),'duplicate_entries_across_children':len(allurls)-len(set(allurls)),'nonpreferred_urls':[u for u in allurls if not u.startswith(PREFERRED+'/')]},'baked_peaches':next((r for r in RESULTS if r['url']==PREFERRED+'/recipes/baked-peaches-with-cinnamon/'),None)}
for r in RESULTS:
 key=str(r.get('status','unverified'));report['verified_status_counts'][key]=report['verified_status_counts'].get(key,0)+1
(OUT/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('SUMMARY',json.dumps({k:v for k,v in report.items()if k not in['baked_peaches','stopped_origins']},ensure_ascii=False),flush=True)
