# Recovered live audit evidence

This package copies existing saved evidence. Recovery/validation made no network requests, repository edits, hosting changes, merge or deployment.

Base commit: `9ebb8489fcd60909be13623c24b25a86b5dbd115`.

## October23 catalogue run

`full-catalogue/combined-url-audit.csv` contains all5,871intended canonical URLs with static evidence and the original live outcome. `full-catalogue/url-results.csv` is the HTTP-focused table. Both tables were cross-checked against every original `responses.jsonl` record, including exact URL identities:

- **1,216 verified origin200s:** all356nonrecipe pages and860recipes. All matched the base HTML bytes/canonical and had no accidental noindex or Recipe-entity/JSON-LD defect in original HTML.
- **4,655 origin-unverified URLs:**4,654unrequested plus Canederli, whose execution proxy returned503before reaching a verified origin response. This is not a confirmed website503, stale deployment or recipe defect.
- The run started2026-10-23T03:27:44.770604Z and stopped2026-10-23T03:31:54.664235Z. `transport-recovery-control.json` preserves the later03:36:16UTCrobots request that hit the same execution-proxy tunnel failure. No full crawl resume or additional site probe was performed during evidence recovery.

The exact1,216successful identities are now available again, not inferred from ordering. `verified-origin-urls.csv` lists them with original timestamps and body hashes; `origin-unverified-urls.csv` lists every remaining intended URL. From the recovered JSONL, the860recipe successes are exactly the first860recipes sorted by full URL; `canederli` is recipe index860(zero-based). `candy-apples` and `candy-cane-cookies` finished after the proxy stop as already in-flight requests. These completion details are why the mapping was not guessed while the environment was offline.

Legacy raw `stats.json` fields count1,217network responses including the proxy503and one proxy-body byte mismatch. Use `verified_origin_http_rows=1216`, `origin_unverified_rows=4655`, `origin_status_counts={200:1216}`, `byte_different_origin_html=0` and `complete_origin_live_coverage=false` for production-origin claims. The raw record remains unchanged as evidence.

## Historical October22 sample

`historical-2026-10-22/` preserves61unique targets and80observations, including16self307observations, exact request IDs, normal-client confirmations and raw header/body files. All12child sitemaps were fetched successfully at least once and contained5,871unique preferred URLs. Successes did not erase the intermittent self-redirect observations. The307body was plain nginx redirect HTML with no JS/CAPTCHA/cookie/Retry-After challenge. Its exact generator remains unproven; it must not be conflated with the later explicit execution-proxy tunnel failure.

## Files and portability

Raw evidence is copied byte for byte. Some raw JSON fields retain the original absolute workspace `body_file`/`headers_file` paths. Resolve them as follows:

- Original `.../live/full-catalogue/` maps to this package's `full-catalogue/`.
- Original `.../live/bodies/`, `.../live/redirect-confirmation/`, and `.../live/protocol-comparison/` map to the same folders inside `historical-2026-10-22/`.
- Original `.../live/recovery-control.json` maps to `transport-recovery-control.json`.

`validation.json` records exact row-set checks. `SHA256SUMS.txt` covers the copied package files. `crawl.py` and `summarise.py` are the exact artifact scripts; do not rerun a stopped crawler automatically or treat its local `complete` flag as proof of full origin coverage.

These are technical access/source observations, not Google indexing evidence. No URL is labelled indexed, and ordinary owner-audit requests are not verifiedGooglebot tests.
