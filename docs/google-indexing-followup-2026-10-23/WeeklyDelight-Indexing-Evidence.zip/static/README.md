# Current-main static crawling and indexing audit

Audited base: `9ebb8489fcd60909be13623c24b25a86b5dbd115` (current `main` after PR #26). Read-only worktree: `/workspace/Culinaryrecipie-indexing`, branch `audit/google-indexing-followup-2026-10-22`. Audit date: 22 October 2026. No source, generated page, content, advertising or date-register file was changed by this audit. The parent agent is separately changing the optional step-name template; these results describe the generated base before regeneration.

The full generated catalogue passes the existing strict crawl audit. There is **no confirmed remaining shared static crawl/indexability blocker** in this output. Production status and Google indexing require separate evidence.

## Exact coverage

| Source | Count / reconciliation |
| --- | --- |
| Recipe catalogue rows | 5,515 |
| Joined detail records | 5,515, across 62 catalogue files / 388 detail files |
| Generated recipe pages | 5,515, plus the `/recipes/` directory |
| Intended indexable routes | 5,871: 5,515 recipes; 10 categories; 193 category combinations; 92 cuisines; 51 ingredient hubs; 10 other indexable pages |
| Generated HTML files | 5,878 total: 5,871 intended pages; 4 deliberate nonindexable helpers; 3 noindex advertising frames |
| Sitemap URLs | 5,871 unique, exact match to intended routes, zero extra/missing/duplicate entries |
| Sitemap files | 1 canonical index, 1 byte-identical legacy `sitemap.xml` alias, 12 children: 11 × 490 entries and 1 × 481 |
| Reachable intended URLs | All 5,871, by ordinary followable HTML anchors, across 250,155 unique directed edges |
| Homepage navigation depth | 1 at depth 0, 66 at depth 1, 5,804 at depth 2; no intended URL deeper or unreachable |
| Distinct internal anchor targets | 5,884 from intended pages: all 5,871 routes + 10 intentional query filters + favourites + attribution Markdown + sitemap index. Counting helper self-links too gives 5,887 |
| Supplied Search Console rows | Exactly 1,000 unique URLs: 920 recipes, 40 combinations, 19 cuisines, 17 ingredients, 1 category, 3 other pages. Every row is inside current catalogue |

`wc -l` returns 1,000 for the CSV including its header because the last record lacks a final newline. A CSV reader confirms 1,000 **data** rows. Do not reduce this to 999.

The 1,000 historical supplied rows are a subset of the screenshot's approximately 2,982 “Discovered — currently not indexed” URLs. The other approximately 1,982 affected URLs have not been supplied; their exact identities are unknown. No individually confirmed indexed URLs were provided for comparison. All supplied rows say validation `Pending`, with `1970-01-01` in the export's crawl field; that is treated as unavailable crawl evidence, not as an actual 1970 crawl or proof the URL was never crawled. The export metadata contains no freshness timestamp. All other indexing statuses remain unknown. Neither static eligibility nor HTTP 200 means indexed.

## Verified static results

- All 5,871 intended pages have exactly one correct preferred-host HTTPS canonical, no accidental noindex/nofollow/none directive, a unique title and H1 identity, substantive HTML and a local sitemap entry. Existing SEO audit also verifies distinct meta descriptions and contextual inbound links.
- All 5,515 recipe pages expose exactly one Recipe JSON-LD entity and zero Recipe microdata/RDFa declarations. Ingredients, instructions, yield, author, supported times and dates agree with the source and visible HTML. The historical baked-peaches duplicate Recipe is absent from current generated HTML.
- There are 31,893 instruction steps; source step fragments and normal HTML anchor targets resolve. The supplemental audit checked 33,821 fragment links representing 16,918 unique page/fragment targets: zero missing targets.
- 443 required-untimed recipes omit a falsely complete `totalTime`; 5,072 carry a supported total. None of the 5,515 publishes an aggregate rating without evidence (all currently omit ratings).
- 5,227 recipe schemas declare an image; all declared local image files exist. 288 omit Recipe.image, which limits recipe rich-result eligibility but does not make the page nonindexable. No image was invented or inserted by this audit. Live image HTTP access is separate.
- Sitemap XML parses, uses the preferred canonical origin, has no duplicate entries, and omits no intended route. Every entry's `lastmod` equals its committed content-date register; every recipe entry also equals Recipe.dateModified. Index lastmods equal the newest member in each child; no date is malformed or in the future. This validates consistency, not the historical truth of every editorial modification.
- No broken internal anchor destination and no unintended HTTP/www/index.html link target were found. Ten parameter URLs are intentional directory filters, omitted from sitemaps and disallowed by repository robots.txt. They do not represent orphan recipes: every intended recipe is linked from normal HTML independent of filters or JavaScript.
- Category/cuisine/ingredient collections expose their listed recipe links in original HTML. “Show more” is progressive client functionality, not the only discovery route. No missing crawlable category pagination was found.
- `robots.txt` passes 150 URL/crawler checks (25 × 6); static private-path rules pass 22 refused/18 served cases. These tests inspect repository rules, not deployed Hostinger behavior. HTTP/X-Robots-Tag, redirect chains, challenges and status codes must come from the separate live audit.

## Remaining review work

1. The generated baseline uses optional `HowToStep.name` values `Step 1`, `Step 2`, etc. for all 31,893 steps. This is a confirmed shared markup-quality issue relative to Google's action-summary guidance, **not a demonstrated crawl or indexing block**. Names are optional; omitting the generic labels while retaining complete visible text and real fragment URLs is an appropriate source-template correction. The parent agent is implementing and testing it separately.
2. Seventy collections (52 category combinations and 18 cuisine pages) have only 1–5 recipes (2 with one, 3 with two, 6 with three, 29 with four, 30 with five). Their exact URLs, identities and listed recipe URLs are in `small-collections-review.csv`. Assess whether each helps navigation and has useful context; a small count alone does not prove thin content or justify mass deletion/noindex.
3. Static schema agreement is not independent cooking, ingredient, food-safety, diet-label or duplication validation. Existing Claude content findings and recipe-photo variation notes remain separate evidence queues. No cooking evidence was invented.
4. Production fetchability, preferred-host/path redirects, response headers/statuses, real rendered third-party script behavior and Google Rich Results validation need separate checks. This report makes no claim that local success fixes Google-controlled selection, crawl scheduling or indexing.

The four excluded helper files are `404.html`, `favourites/index.html`, `contact/_pages/sent.html`, and `contact/_pages/not-sent.html`; each deliberately declares noindex. The contact result templates are additionally denied by repository server rules. All three existing advertising frames declare noindex/nofollow and remain unchanged.

## Files and reproducibility

- `manifest-current.json`: source route, layout, recipe-field and identity inventory.
- `catalogue-audit-current.json`: full existing audit results, URLs and historical Search Console evidence.
- `catalogue-audit-current.log`: concise strict audit output.
- `url-level-static-audit.csv`: all 5,871 intended URL outcomes, with indexing status explicitly historical/unknown and HTTP unverified by this audit.
- `all-generated-html-inventory.json`: all 5,878 files, canonical/robots/Recipe declarations and raw HTML SHA-256 hashes.
- `internal-anchor-targets.csv`: all 5,887 distinct targets from all generated HTML, with incoming-page counts.
- `small-collections-review.csv`: 70 exact collection review items, not confirmed defects.
- `extra-inventory-summary.json`: independent fragment, lastmod/register and Recipe/step checks.
- `tool-exit-results.json` plus individual tool logs: all reused commands returned zero; crawl guard 14 cases, content-date guard 10 cases, Python crawl parser/audit 19 cases.

Six recipe layout variants were covered across the complete output: 947 mistakes-first, 925 cook-first, 923 table-led, 914 questions-led, 909 make-ahead and 897 classic. Representative rendered tests should include all six plus home, directory, category, combination, cuisine, ingredient, search, no-image and required-untimed variants. No browser/Google validation is claimed in this static report.
