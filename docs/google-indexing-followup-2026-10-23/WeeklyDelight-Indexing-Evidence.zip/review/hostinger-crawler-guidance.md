**Hostinger crawler-access and self-redirect handoff — 22 October 2026**

Selected requests show same-path 307 responses delivered through Hostinger CDN; other requests succeed. These tests passed through the session network proxy. They establish a reproducible access concern for these clients, not the response Googlebot receives or the precise layer that created it. The request ID identifies the delivery path; Hostinger must trace the generating rule. [Hostinger troubleshooting](https://www.hostinger.com/support/hostinger-cdn-troubleshooting-website-errors/)

Hostinger documents normal verified-crawler access and warns that Under Attack mode can block crawlers. The active configuration has not been read. [Crawler access](https://www.hostinger.com/support/hostinger-cdn-search-engine-crawlers-and-seo/) [Under Attack mode](https://www.hostinger.com/support/8512979-hostinger-cdn-the-under-attack-mode/)

**Owner steps in hPanel**

1. Sign in to hPanel, open Websites, find weeklydelight.com and choose Dashboard. [Official instructions](https://www.hostinger.com/support/10695636-hostinger-cdn-security-levels/)
2. Open Performance → CDN; if the plan places CDN directly in the sidebar, use that. Record current status; do not enable an inactive CDN for this test. [Official instructions](https://www.hostinger.com/support/hostinger-cdn-troubleshooting-website-errors/)
3. Choose Manage → Security and record the Security level. If Under Attack is active and the attack has ended, use Medium or Low as Hostinger documents; do not turn all protection off. [Official instructions](https://www.hostinger.com/support/hostinger-cdn-search-engine-crawlers-and-seo/)
4. Review Traffic blocking IP/country rules and explicit blocked-bot entries for unintended crawler exclusions. Do not blindly allow a Googlebot user-agent or unrelated networks. [Official instructions](https://www.hostinger.com/support/hostinger-cdn-search-engine-crawlers-and-seo/)
5. After each targeted change, run Search Console URL Inspection → Test live URL on affected pages and review Settings → Crawl stats. A pass proves access, not indexing. [Official instructions](https://www.hostinger.com/support/hostinger-cdn-search-engine-crawlers-and-seo/)
6. If controls are absent or redirects persist, give Hostinger support the exact URL, UTC time, status, Location and x-hcdn-request-id samples below; ask which layer generated the 307. Crawler-rate limits are not editable in hPanel. [Official instructions](https://www.hostinger.com/support/hostinger-cdn-search-engine-crawlers-and-seo/)

On Agency plans, advanced Security controls may be unavailable; ask Hostinger support rather than looking for nonexistent buttons. [Security-level availability](https://www.hostinger.com/support/10695636-hostinger-cdn-security-levels/)

**Cache and redirect diagnosis**

Development mode skips CDN cache, not security; turn it off after diagnosis. If skipping cache removes stale behaviour, flush the CDN cache. Server cache is separate, and purging does not repair an active bad redirect rule. [Cache controls](https://www.hostinger.com/support/hostinger-cdn-how-to-clear-the-cache/)

Hostinger identifies competing proxies and HTTPS/manual-rule conflicts as possible redirect-loop causes. Check the real configuration; do not assume this applies solely from one header. This site is static, so WordPress/plugin instructions do not automatically apply. [Redirect troubleshooting](https://www.hostinger.com/support/hostinger-cdn-troubleshooting-website-errors/)

Google treats 307 as a temporary redirect, broadly like 302. For robots.txt specifically, it follows at least five redirect hops and then applies 404/no-rules behaviour; that is different from robots 5xx unavailability. Do not report a robots 307 loop as a confirmed site-wide Disallow or claim it necessarily halts all crawling. [HTTP codes](https://developers.google.com/crawling/docs/troubleshooting/http-status-codes) [Robots status handling](https://developers.google.com/crawling/docs/robots-txt/robots-txt-spec)

**Evidence to give Hostinger**

| URL | UTC observation | Final HTTP / Location | x-hcdn-request-id |
| --- | --- | --- | --- |
| https://weeklydelight.com/robots.txt | 2026-10-22T20:31:45.168909+00:00 | 200 / none | 7a1ae30de3514f3f38874f75d613acad-bos-edge8 |
| http://www.weeklydelight.com/recipes/baked-peaches-with-cinnamon/ | 2026-10-22T20:31:52.873986+00:00 | 307 / /recipes/baked-peaches-with-cinnamon/ | ebe5c82a906c6a3dda046481dcaba3a9-bos-edge9 |
| http://www.weeklydelight.com/categories/baking/italian/ | 2026-10-22T20:31:54.165951+00:00 | 307 / /categories/baking/italian/ | 896780e2ccf4af5971be54e575aec7da-bos-edge14 |
| https://weeklydelight.com/robots.txt | 2026-10-22T20:33:37.181260+00:00 | 307 / /robots.txt | d73ae4dde43612807e2d4293fc5a4d11-bos-edge14 |
| https://weeklydelight.com/robots.txt | 2026-10-22T20:33:38.935221+00:00 | 307 / /robots.txt | 0ad0eff7c2d93a41ea587c71b1aba276-bos-edge9 |

**Support message draft—ready for the owner to paste**

Please investigate intermittent self-referential HTTP 307 responses on weeklydelight.com. An ordinary GET to https://weeklydelight.com/robots.txt returned 307 with Location: /robots.txt at 2026-10-22T20:33:37.181260Z, request ID d73ae4dde43612807e2d4293fc5a4d11-bos-edge14. At 20:31:45.168909Z the same URL returned 200, request ID 7a1ae30de3514f3f38874f75d613acad-bos-edge8. Also https://weeklydelight.com/sitemap-2.xml returned 307 with Location: /sitemap-2.xml at 20:33:42.986583Z, request ID a63931169d7a583e782890fa0bcb46dd-bos-edge10. Tests used a managed network proxy; these samples do not establish that Googlebot received the same response. Please identify the generating layer/rule, inspect CDN security, blocked bots, country/IP filters, HTTPS settings and upstream rewrites, and check actual verified Googlebot requests. Keep public recipes, robots and sitemaps accessible while preserving legitimate security and monetization. We have not changed production hosting settings.

**Exact remaining access limit**

Read/modify production hPanel CDN security, traffic-blocking and cache controls and inspect provider logs; no authenticated Hostinger configuration tool is available in this session. GitHub/repository access does not confer hPanel access.

No production settings were changed and no support message was sent. Successful access still does not guarantee Google indexing.
