# Claude: remaining authored timing claims and evidence questions

Baseline: `9ebb8489fcd60909be13623c24b25a86b5dbd115`, reviewed 22 October 2026. Recipe content and culinary-evidence decisions remain Claude’s. Codex’s shared SEO gating prevents newly generated precise whole-recipe promises when a required wait is unquantified; it does not rewrite the authored source fields below. None of these review records is silently closed by the technical change.

## Authored time claims still requiring review

The historical queue contains **37 still-present authored claim records across 35 recipes**. Each still has an unquantified wait in the current loaded method. This is a review list, not 35 confirmed broken recipes: determine whether the wait is required, optional or genuinely overlaps documented preparation before changing a time. Do not invent cooling minutes. If no complete elapsed duration is supported, qualify or remove the unsupported ready-in promise while retaining supported preparation and cooking figures.

`description` below maps to the detail record’s `d`; `meta` maps to its `meta`. Paths point to the start of the current recipe record. The exact authored field text and full current methods/ingredients are in `content-review.json`.

| Recipe identifier | Current source record | Field | Claim text from the historical record | Unquantified stage(s) |
| --- | --- | --- | --- | --- |
| `apple-turnovers` | `src/data/details22/puddings.js:161` | `meta` | Ready in 45 minutes | cooling completely |
| `greek-eggplant-salad` | `src/data/details32/04b-vegetable-sides.js:103` | `description` | servings in 40 minutes | cooling to room temperature |
| `caramel-popcorn` | `src/data/details38/03-breads-snacks-and-meal-prep.js:190` | `description` | servings in 30 minutes | cooling completely |
| `freezer-meatballs` | `src/data/details38/03-breads-snacks-and-meal-prep.js:373` | `description` | servings in 40 minutes | cooling completely |
| `sweet-potato-brownies` | `src/data/details38/03-breads-snacks-and-meal-prep.js:473` | `description` | servings in 45 minutes | cooling completely |
| `spicy-tuna-roll` | `src/data/details49/02-south-east-asia-japan-and-the-gulf.js:529` | `meta` | servings, ready in 50 minutes | cooling the rice |
| `air-fryer-brownies` | `src/data/details53/01-air-fryer-a.js:81` | `meta` | servings, ready in 30 minutes | cooling completely |
| `air-fryer-empanadas` | `src/data/details53/01-air-fryer-a.js:387` | `meta` | servings, ready in 42 minutes | cooling completely |
| `banana-cupcakes` | `src/data/details55/01-cookies-cakes-and-biscuits-a.js:329` | `meta` | servings, ready in 45 minutes | cooling completely |
| `cakey-brownies` | `src/data/details55/01-cookies-cakes-and-biscuits-a.js:648` | `meta` | servings, ready in 50 minutes | cooling completely |
| `caramel-blondies` | `src/data/details55/01-cookies-cakes-and-biscuits-a.js:686` | `meta` | servings, ready in 50 minutes | cooling completely |
| `coconut-cupcakes` | `src/data/details55/02-cookies-cakes-and-biscuits-b.js:364` | `meta` | servings, ready in 50 minutes | cooling completely |
| `funfetti-cupcakes` | `src/data/details55/02-cookies-cakes-and-biscuits-b.js:788` | `meta` | servings, ready in 50 minutes | cooling completely |
| `gluten-free-brownies` | `src/data/details55/02-cookies-cakes-and-biscuits-b.js:826` | `meta` | ready in 40 minutes | cooling completely |
| `white-chocolate-raspberry-blondies` | `src/data/details55/03-lemon-nutella-oat-and-peanut-butter.js:377` | `meta` | ready in 50 minutes | cooling completely |
| `nutella-brownies` | `src/data/details55/03-lemon-nutella-oat-and-peanut-butter.js:411` | `meta` | ready in 35 minutes | cooling completely |
| `peanut-butter-cupcakes` | `src/data/details55/03-lemon-nutella-oat-and-peanut-butter.js:791` | `meta` | servings, ready in 55 minutes | cooling completely |
| `pumpkin-cupcakes` | `src/data/details55/04-pumpkin-caramel-cakes-and-pies.js:249` | `meta` | servings, ready in 50 minutes | cooling completely |
| `raspberry-brownies` | `src/data/details55/04-pumpkin-caramel-cakes-and-pies.js:290` | `meta` | ready in 45 minutes | cooling completely |
| `maple-walnut-cookies` | `src/data/details55/04-pumpkin-caramel-cakes-and-pies.js:395` | `meta` | ready in 40 minutes | cooling completely |
| `zucchini-brownies` | `src/data/details55/04-pumpkin-caramel-cakes-and-pies.js:820` | `meta` | ready in 45 minutes | cooling completely |
| `apple-pie-filling` | `src/data/details56/02-pastries-puddings-and-mug-cakes.js:519` | `meta` | ready in 35 minutes | cooling completely |
| `dairy-free-brownies` | `src/data/details56/03-no-bake-pies-and-dairy-free-a.js:537` | `meta` | ready in 45 minutes | cooling completely |
| `dairy-free-cupcakes` | `src/data/details56/03-no-bake-pies-and-dairy-free-a.js:671` | `meta` | servings, ready in 50 minutes | cooling completely |
| `gluten-free-cupcakes` | `src/data/details56/04-special-diet-sweets-and-ice-creams.js:119` | `meta` | servings, ready in 57 minutes | cooling completely |
| `vegan-cupcakes` | `src/data/details56/04-special-diet-sweets-and-ice-creams.js:359` | `meta` | servings, ready in 50 minutes | cooling completely |
| `gluten-free-crackers` | `src/data/details57/02-gluten-free-mains-and-bakes-a.js:82` | `meta` | ready in 35 minutes | cooling on the tray |
| `low-carb-granola` | `src/data/details57/04-high-protein-and-low-carb-a.js:386` | `meta` | servings, ready in 35 minutes | cooling completely |
| `vegan-granola` | `src/data/details57/06-vegan-b.js:43` | `meta` | servings, ready in 35 minutes | cooling completely |
| `poire-belle-helene` | `src/data/details58/01-french-classics-a.js:769` | `description` | ready in 35 minutes | cooling |
| `poire-belle-helene` | `src/data/details58/01-french-classics-a.js:769` | `meta` | servings, ready in 35 minutes | cooling |
| `sbrisolona-mantovana` | `src/data/details59/03-italian-d.js:707` | `meta` | servings, ready in 55 minutes | cooling completely |
| `kokosmakronen` | `src/data/details60/02-german-b.js:779` | `meta` | ready in 35 minutes | cooling |
| `ovos-moles` | `src/data/details61/03-portuguese-greek.js:214` | `description` | ready in 45 minutes | cooling completely |
| `ovos-moles` | `src/data/details61/03-portuguese-greek.js:214` | `meta` | servings, ready in 45 minutes | cooling completely |
| `mazurek` | `src/data/details62/01-polish-czech-a.js:84` | `meta` | servings, ready in 55 minutes | cooling the base, setting the topping for a few hours |
| `brunede-kartofler` | `src/data/details62/04-swedish-danish-finnish-irish.js:266` | `meta` | servings, ready in 40 minutes | cooling |

The other **35** historical time-claim records have changed wording. They also require fresh review rather than automatic closure or carrying the historical text forward as if unchanged. All **152** historical short-wait texts still exist; the available text does not, by itself, settle every overlap/allocation decision. Do not add every rest to the row time mechanically.

## Findings already reconciled in current source

- `chocolate-pots`: yolks now expressly pasteurised (or British Lion-stamped in the UK).
- Unsupported Gluten-Free tags were removed from `panettone-bread-pudding`, `slow-cooker-beef-ragu`, `tortellini-panna-e-prosciutto`, `cannelloni-ricotta-e-spinaci` and `pull-apart-cheese-bread`.
- Unsupported Dairy-Free tags were removed from `nutella-cookies` and `nutella-brownies`; `florida-grouper-sandwich` no longer carries Vegetarian.
- `edible-cookie-dough`, `cookie-dough-bites` and the unbaked topping of `cookie-dough-bars` now require flour sold as heat-treated and ready to eat raw. Ordinary flour in the bars is expressly for the baked base.

These are confirmed source-text corrections. Historical raw-flour queue rows still need an explicit recorded disposition, and product suitability remains a real label/evidence question. They are not kitchen-testing results, allergen certification or practical cooking validation.

## Evidence dependencies still open

Four farmed-salmon supplier/exemption questions remain in `gravlax`, `lomi-lomi-salmon`, `chirashi-bowl` and `salmon-poke-bowls`. Five specialist records remain for raw prawns (`aguachile`), raw beef (`steak-tartare`, `carpaccio`) and recipe-specific preservation evidence (`lime-pickle`, `mango-pickle`). The pickle ledger’s assertion about acidity is not a measured finished-mixture pH. Preserve the exact evidence dependency and seek a justified disposition; do not manufacture pH, product, cooking or safety evidence.

All 26 testing-register entries remain “not cooked”. Keep the current honest AI/no-kitchen-testing disclosure. Add original cooking experience, qualified review or personal credentials only after real evidence exists.

The 15 historical duplicate-intent pairs remain editorial review candidates. The duplicate-audit success message now acknowledges those exceptions rather than implying zero same-dish candidates. Do not bulk delete, redirect, canonicalize together or noindex these recipes solely to lower Search Console exclusions. Compare the exact paired ingredient/method evidence and any available query/indexing performance before proposing a consolidation for owner review.

No URL in this content review is labelled indexed, and these findings do not establish Google’s exact exclusion reason. Recipe-image requirements concern recipe rich-result eligibility; optional schema warnings and a successful local build do not diagnose ordinary indexing.
