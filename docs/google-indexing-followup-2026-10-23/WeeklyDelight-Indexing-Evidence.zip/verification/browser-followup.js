'use strict';
const fs=require('fs'),path=require('path'),http=require('http'),crypto=require('crypto');
const {chromium}=require('playwright');
const ROOT='/workspace/verification-indexing-2026-10-22';
const SOURCE='/workspace/Culinaryrecipie-indexing';
const OUT='/workspace/artifacts/indexing-followup-2026-10-22/verification';
const {loadRecipes,buildContext}=require(path.join(ROOT,'src/build'));
const {layoutFor}=require(path.join(ROOT,'src/lib/layouts'));
const {plainList}=require(path.join(ROOT,'src/lib/ingredients'));
const {addFahrenheit}=require(path.join(ROOT,'src/lib/oven-temp'));
const hubs=require(path.join(ROOT,'src/lib/ingredient-hubs')).build(loadRecipes()).hubs;
const recipes=loadRecipes(),ctx=buildContext(recipes),bySlug=new Map(recipes.map(r=>[r.slug,r]));
const index=JSON.parse(fs.readFileSync(path.join(ROOT,'search-index.json')));
const countAd=require(path.join(ROOT,'tools/native-ad-slot-count'));
const base='http://127.0.0.1:9021',origin='https://weeklydelight.com';
const screenshots=path.join(OUT,'browser-screenshots');fs.mkdirSync(screenshots,{recursive:true});
const digest=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const fileFor=route=>path.join(ROOT,route.split('?')[0],route.split('?')[0].endsWith('/')?'index.html':'');
const layoutCases=[];const seen=new Set();
for(const r of recipes){const l=layoutFor(r).id;if(!seen.has(l)){seen.add(l);layoutCases.push({id:'layout-'+l,route:'/recipes/'+r.slug+'/',slug:r.slug});}}
const cases=[...layoutCases,
 ...['chocolate-milkshake','victoria-sponge','vada-pav','avocado-toast','baked-peaches-with-cinnamon'].map(slug=>({id:slug,slug,route:'/recipes/'+slug+'/'})),
 {id:'missing-image',slug:recipes.find(r=>!r.imageData).slug,route:'/recipes/'+recipes.find(r=>!r.imageData).slug+'/'},
 {id:'organization-photo',slug:recipes.find(r=>r.imageData?.author_type==='Organization').slug,route:'/recipes/'+recipes.find(r=>r.imageData?.author_type==='Organization').slug+'/'},
 {id:'home',route:'/'},{id:'cuisine-index',route:'/cuisines/'},{id:'category-index',route:'/categories/'},{id:'category-hub',route:'/categories/dinner/'},
 {id:'category-combination',route:'/categories/baking/italian/'},{id:'cuisine',route:'/cuisines/italian/'},
 {id:'ingredient-hub',route:'/ingredients/'+(hubs.find(h=>Math.min(...h.recipes.map(r=>r.prep+r.cook))!==Math.min(...h.recipes.filter(r=>!r.untimed?.length).map(r=>r.elapsedTime)))||hubs[0]).slug+'/'},
 {id:'search',route:'/search/'}];
const inputFiles=new Set(cases.map(c=>fileFor(c.route)));
for(const name of ['search-index.json','src/data/content-dates.json','src/templates/recipe-page.js','src/templates/pages.js','src/lib/seo.js','src/build.js','assets/css/main.css','assets/js/app.js','assets/js/directory.js','assets/js/recipe.js'])inputFiles.add(path.join(ROOT,name));
const hashesBefore=Object.fromEntries([...inputFiles].map(f=>[path.relative(ROOT,f),digest(f)]));
const report={testOnly:true,productionRequests:false,thirdPartyRequestsBlocked:true,root:ROOT,baseCommit:'9ebb8489fcd60909be13623c24b25a86b5dbd115',cases:[],flows:[],errors:[],inputHashesBefore:hashesBefore,startedAt:new Date().toISOString()};
const mime={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'application/javascript','.json':'application/json','.jpg':'image/jpeg','.webp':'image/webp','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2','.xml':'application/xml','.txt':'text/plain'};
const server=http.createServer((req,res)=>{let route;try{route=decodeURIComponent(req.url.split('?')[0]);}catch(e){res.writeHead(400).end();return;}let file=path.join(ROOT,route);if(file!==ROOT&&!file.startsWith(ROOT+path.sep)){res.writeHead(403).end();return;}if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');if(!fs.existsSync(file)){res.writeHead(404).end();return;}res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});fs.createReadStream(file).pipe(res);});
const inspect=()=>{
 const all=[];function walk(x){if(Array.isArray(x))x.forEach(walk);else if(x&&typeof x==='object'){if(x['@type'])all.push(x);Object.values(x).forEach(walk);}}
 const invalid=[];document.querySelectorAll('script[type="application/ld+json"]').forEach(s=>{try{walk(JSON.parse(s.textContent));}catch(e){invalid.push(String(e));}});
 const isRecipe=x=>[].concat(x||[]).some(t=>t==='Recipe'||/[/:]Recipe$/.test(t));
 const recipes=all.filter(x=>isRecipe(x['@type']));const schema=recipes[0];
 return {title:document.title,description:document.querySelector('meta[name="description"]')?.content,h1:[...document.querySelectorAll('h1')].map(x=>x.textContent.trim()),canonical:[...document.querySelectorAll('link[rel="canonical"]')].map(x=>x.href),robots:[...document.querySelectorAll('meta[name="robots"],meta[name="googlebot"],meta[http-equiv="X-Robots-Tag"]')].map(x=>x.content),recipeJSONLD:recipes.length,recipeMicrodata:[...document.querySelectorAll('[itemtype]')].filter(x=>isRecipe(x.getAttribute('itemtype'))).length,recipeRDFa:[...document.querySelectorAll('[typeof]')].filter(x=>isRecipe(x.getAttribute('typeof'))).length,invalidJSONLD:invalid,schemaTypes:all.map(x=>x['@type']),recipeSchema:schema,steps:schema?.recipeInstructions.map(s=>({name:s.name,text:s.text,position:s.position,url:s.url,visible:document.querySelector(new URL(s.url).hash+' .step-text')?.textContent})),bodyTextLength:document.body.innerText.length,mainText:document.querySelector('main')?.innerText,viewport:innerWidth,scrollWidth:document.documentElement.scrollWidth,images:[...document.images].map(i=>({src:i.currentSrc||i.src,complete:i.complete,naturalWidth:i.naturalWidth,naturalHeight:i.naturalHeight})),cuisineCards:document.querySelectorAll('section[aria-labelledby="cuisine-list-title"] a.card').length,directoryLinks:[...document.querySelectorAll('main a[href="/recipes/"]')].length,filterGroups:document.querySelectorAll('.filter-group').length,nutritionFigures:document.querySelectorAll('.nutrition strong').length};
};
async function settleImages(page){await page.evaluate(()=>document.querySelectorAll('img').forEach(i=>{i.loading='eager';}));await page.waitForFunction(()=>[...document.images].every(i=>i.complete),null,{timeout:12000}).catch(()=>{});}
async function resultCount(page){await page.waitForFunction(()=>document.querySelector('#result-count strong')||/No recipes|Nothing matches/.test(document.querySelector('#result-count')?.textContent||''));return page.$eval('#result-count',el=>Number((el.querySelector('strong')?.textContent||'0').replace(/[^\d]/g,'')));}
(async()=>{let browser;
 try{
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(9021,'127.0.0.1',resolve);});
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  for(const mode of [{name:'desktop',viewport:{width:1366,height:900}},{name:'mobile',viewport:{width:390,height:844},isMobile:true,hasTouch:true}]){
   const context=await browser.newContext({...mode,reducedMotion:'reduce'});let blocked=0;
   await context.route('**/*',r=>{if(r.request().url().startsWith(base))return r.continue();blocked++;return r.abort();});
   const page=await context.newPage();let currentErrors=[];let localHttpErrors=[];
   page.on('pageerror',e=>currentErrors.push(String(e)));page.on('response',r=>{if(r.url().startsWith(base)&&r.status()>=400)localHttpErrors.push({url:r.url(),status:r.status()});});
   for(const test of cases){currentErrors=[];localHttpErrors=[];const row={mode:mode.name,id:test.id,route:test.route,failures:[]};
    try{const response=await page.goto(base+test.route,{waitUntil:'domcontentloaded',timeout:30000});await page.waitForTimeout(350);await settleImages(page);const d=await page.evaluate(inspect);row.status=response.status();row.observed=d;
     const fail=(ok,msg)=>{if(!ok)row.failures.push(msg);};
     fail(row.status===200,'non200');fail(d.canonical.length===1&&d.canonical[0]===origin+test.route,'canonical');fail(!d.invalidJSONLD.length,'invalid JSON-LD');fail(d.h1.length===1,'H1 count');fail(!d.robots.some(x=>/\b(noindex|nofollow|none)\b/i.test(x)),'indexability directive');fail(d.scrollWidth<=d.viewport+2,'horizontal overflow');fail(d.description.length>=140&&d.description.length<=160,'meta description length');fail(!d.images.some(i=>!i.complete||!i.naturalWidth),'image failure');fail(!currentErrors.length,'uncaught page error');fail(!localHttpErrors.length,'local HTTP error');
     const baseline=fs.readFileSync(path.join(SOURCE,test.route,'index.html'),'utf8');const final=fs.readFileSync(fileFor(test.route),'utf8');row.adCounts={baseline:countAd(baseline),final:countAd(final)};fail(row.adCounts.baseline===row.adCounts.final,'advertising slot count changed');
     if(test.slug){const r=bySlug.get(test.slug);fail(d.recipeJSONLD===1&&d.recipeMicrodata===0&&d.recipeRDFa===0,'primary Recipe count');fail(d.schemaTypes.includes('BreadcrumbList'),'breadcrumbs missing');fail(d.steps.length===r.steps.length,'step count');fail(d.steps.every((s,i)=>s.name===undefined&&s.position===i+1&&s.text===r.steps.map(addFahrenheit)[i]&&s.visible===s.text&&s.url===origin+test.route+'#step-'+(i+1)),'steps/text/names/order/anchors');fail(d.recipeSchema.recipeIngredient.join('\n')===plainList(r.ingredients).join('\n'),'ingredients changed');fail(d.bodyTextLength>1000,'substantive recipe content');
      if(r.untimed?.length){fail(!d.recipeSchema.totalTime,'untimed schema total');const promises=d.description.match(/(?:Ready in \d+ minutes|Takes [^.]*start to finish)/ig)||[];row.existingAuthoredTimeClaims=promises.filter(p=>r.meta.toLowerCase().includes(p.toLowerCase()));fail(promises.every(p=>r.meta.toLowerCase().includes(p.toLowerCase())),'new generated untimed snippet promise');fail(!/\bin \d+ Minutes\b/i.test(d.title.replace(r.title,'')),'new untimed title promise');}
      if(r.nutritionTier===3){fail(!/nutrition|calories|kcal/i.test(d.description),'withheld nutrition snippet claim');fail(!d.nutritionFigures&&/No nutrition figures are given/i.test(d.mainText),'withheld visible figures');}
      if(test.id==='organization-photo'){const image=Array.isArray(d.recipeSchema.image)?d.recipeSchema.image[0]:d.recipeSchema.image;fail(image?.creator?.['@type']==='Organization','organization image creator');}
     }else{fail(d.recipeJSONLD===0&&d.recipeMicrodata===0&&d.recipeRDFa===0,'unexpected Recipe');}
     if(test.id==='cuisine-index')fail(d.cuisineCards===ctx.topCuisines.length&&d.h1[0]===`${ctx.topCuisines.length} cuisines, mapped`,'dynamic cuisine count');
     if(['category-index','category-hub'].includes(test.id)){fail(d.directoryLinks>0,'directory navigation missing');fail(!/Each category is filtered further|Filter by cuisine, diet, difficulty and time\./.test(d.description+' '+d.mainText),'unsupported category filters claim');}
     if(test.id==='ingredient-hub'){const h=hubs.find(h=>'/ingredients/'+h.slug+'/'===test.route);const candidates=h.recipes.filter(r=>!r.untimed?.length&&Number.isFinite(r.elapsedTime)&&r.elapsedTime>0);const min=Math.min(...candidates.map(r=>r.elapsedTime));const clock=/\bfrom (\d+) minutes/i.exec(d.description);row.hubTiming={eligibleTimedRecipes:candidates.length,minimumCompleteMinutes:Number.isFinite(min)?min:null,claimedMinutes:clock?Number(clock[1]):null};if(clock)fail(Number(clock[1])===min,'hub complete time claim');}
     row.pageErrors=currentErrors;row.localHttpErrors=localHttpErrors;row.screenshot=path.join(screenshots,`${mode.name}-${test.id}.png`);await page.screenshot({path:row.screenshot,fullPage:false});
    }catch(e){row.failures.push(String(e));}
    report.cases.push(row);console.log(mode.name,test.id,row.failures.length?'FAIL '+row.failures.join('; '):'PASS');
   }
   // Exercise real directory controls as well as read-only template invariants.
   const flow={mode:mode.name,name:'directory-and-search-controls',failures:[]};
   try{await page.goto(base+'/recipes/',{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>document.querySelectorAll('#results .card').length>0);flow.initial=await resultCount(page);if(flow.initial!==index.length)flow.failures.push('catalogue count');
    await page.locator('[data-filter="tag"][value="Vegan"]').check();await page.waitForTimeout(250);flow.vegan=await resultCount(page);flow.expectedVegan=index.filter(r=>r.f.includes('Vegan')).length;if(flow.vegan!==flow.expectedVegan)flow.failures.push('Vegan filter count');
    await page.locator('[data-filter="tag"][value="Vegan"]').uncheck();await page.locator('[data-filter="time"][value="30"]').check();await page.waitForTimeout(250);flow.quick=await resultCount(page);flow.expectedQuick=index.filter(r=>r.m<=30&&!r.u).length;if(flow.quick!==flow.expectedQuick)flow.failures.push('complete-time filter');
    await page.goto(base+'/recipes/',{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>document.querySelectorAll('#results .card').length>0);await page.locator('#directory-query').fill('baked peaches with cinnamon');await page.waitForTimeout(600);flow.searchTitles=await page.locator('#results .card h3').allTextContents();if(!flow.searchTitles.some(t=>t.trim()==='Baked Peaches with Cinnamon'))flow.failures.push('search target');
    await page.goto(base+'/recipes/?sort=quickest',{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>document.querySelectorAll('#results .card').length>0);flow.sort=await page.locator('#sort').inputValue();if(flow.sort!=='quickest')flow.failures.push('quickest selection');flow.ratingOption=await page.locator('#sort option[value="rating"]').count();if(flow.ratingOption)flow.failures.push('unsupported rating sort');
    await page.goto(base+'/search/?q=baked%20peaches%20with%20cinnamon',{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>document.querySelectorAll('#results .card').length>0);flow.fullSearchTitles=(await page.locator('#results .card h3').allTextContents()).slice(0,5);if(!flow.fullSearchTitles.some(t=>t.trim()==='Baked Peaches with Cinnamon'))flow.failures.push('full search target');
    if(mode.name==='mobile'){await page.goto(base+'/',{waitUntil:'domcontentloaded'});await page.locator('#nav-toggle').click();flow.mobileMenuOpen=await page.locator('#nav-toggle').getAttribute('aria-expanded');if(flow.mobileMenuOpen!=='true')flow.failures.push('mobile menu');await page.locator('#nav-toggle').click();}
   }catch(e){flow.failures.push(String(e));}report.flows.push(flow);console.log(mode.name,'controls',flow.failures.length?'FAIL '+flow.failures.join('; '):'PASS');report[mode.name+'BlockedThirdPartyRequests']=blocked;await context.close();
  }
 }catch(e){report.errors.push(String(e));}finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));report.finishedAt=new Date().toISOString();report.inputHashesAfter=Object.fromEntries([...inputFiles].map(f=>[path.relative(ROOT,f),digest(f)]));report.inputsUnchanged=JSON.stringify(report.inputHashesBefore)===JSON.stringify(report.inputHashesAfter);report.failedCases=report.cases.filter(r=>r.failures.length).length;report.failedFlows=report.flows.filter(r=>r.failures.length).length;fs.writeFileSync(path.join(OUT,'browser.json'),JSON.stringify(report,null,2)+'\n');console.log('RESULT',JSON.stringify({cases:report.cases.length,failed:report.failedCases,flows:report.flows.length,failedFlows:report.failedFlows,errors:report.errors,inputsUnchanged:report.inputsUnchanged}));if(report.failedCases||report.failedFlows||report.errors.length||!report.inputsUnchanged)process.exitCode=1;}
})();
