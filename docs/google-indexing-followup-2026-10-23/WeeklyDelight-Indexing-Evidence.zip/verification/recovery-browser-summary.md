# Recovered browser verification — 23 October 2026

**The saved final browser evidence passes.** I independently inspected `browser.json`, the completed log, the code-review report and three saved screenshots after access returned. No browser run or build was repeated. The earlier provisional browser-verification limitation is superseded by this evidence.

- **42 rendered cases passed:** 21 desktop and 21 mobile, zero failed cases, uncaught page errors or recorded local HTTP errors. All 42 screenshots exist. Coverage includes all six recipe layouts, required-untimed and withheld-nutrition recipes, baked peaches, missing-image fallback, Organization photo creator, home, cuisine/category indexes, collection/ingredient hubs and search.
- Recipe checks retained one primary Recipe JSON-LD, zero Recipe microdata/RDFa, complete visible instructions and real anchors, with no generic numbered step names. Canonicals, indexing directives and snippet lengths passed. No new generated untimed-time or withheld-nutrition promise appeared in tested cases; existing authored duration claims remain editorial review items.
- **Both control flows passed:** 5,515 catalogue recipes, 720 Vegan-filter results and 1,480 supported under-30-minute results; baked-peaches search worked in directory and full search, quickest sorting remained available, unsupported rating sorting was absent and the mobile menu opened correctly.
- All **978 observed image instances** loaded; no horizontal overflow was recorded. Every tested page retained its baseline native-ad-slot count. Third-party requests were blocked only in this test context; ad delivery itself was not tested.
- All **31 input-file hashes** were identical before/after. All **nine reviewed source files** match their independent-review SHA-256 hashes in both the current worktree and isolated build. Implementation reference: `e822110d70`; documentation before this recovery update: `62568de0a9`.

The original run started at **2026-10-23T03:39:42.689Z** and finished at **2026-10-23T03:40:25.098Z**, recording `failedCases=0`, `failedFlows=0`, `errors=[]`, `inputsUnchanged=true`. Independent code review has no blocking or nonblocking findings; all three focused checks and the unchanged duplicate audit passed.

| Evidence | SHA-256 |
| --- | --- |
| browser.json | `c5cc57d7b2caf6fea561879a589bf28fda6b767fe31cb89b98478833f795b34b` |
| browser.log | `f3a52d890abf04cf6b0953cd44b96ffd4f3ef08e658df9740ffd80155f7c751f` |
| independent-code-review.json | `da1a94542c4f6dbb8173952cbcf8c100a7b9767bf1a6e2d672dc7216cc534940` |

This verifies reviewed local output, not production HTTP/headers, third-party ad behavior, Google's Rich Results validation or actual indexing. No source or repository documentation was edited, and no merge or deployment was performed by this recovery review.
