Weekly Delight — merged changes and Claude handoff — 21 October 2026

Open WeeklyDelight-Claude-Handoff.pdf on iPhone, or give the text copy to Claude.
PRs #17 and #18 are merged. The implementation commit is 260ad311d43ed3833fd52384f3ae8af9f4e90d19.

Evidence boundaries:
- url-audit-original-2026-10-20.csv is the dated original crawl snapshot, before the 178 photos. URL membership is preserved; use the photo outcomes CSV to update image gaps.
- live-samples.json is a small dated 21 October sample, not a full live crawl. The new Leche Flan photo files returned 404 and that page did not yet reference the photo. A complete production photo rollout is not confirmed.
- No Google indexing or Google Rich Results Test pass is claimed.
- UNMERGED-validator-source-review.patch is a separate earlier source patch for review only. It was not applied to main; read its README and reconcile conflicts before using it.
- Keep recipe/content ownership with Claude and retain all photo credits/licences.
