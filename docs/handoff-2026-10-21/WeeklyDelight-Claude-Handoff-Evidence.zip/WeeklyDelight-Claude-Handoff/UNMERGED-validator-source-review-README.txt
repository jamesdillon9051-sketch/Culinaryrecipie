REVIEW ONLY — NOT INCLUDED IN THE MERGED PRODUCTION CHANGES

This is the staged source patch from /workspace/Culinaryrecipie, branch fix/recipe-validation-review, based on 40a2386f0f0b75eeac0ec54570f619b07f1f2a66. It is separate from PRs #17/#18. It includes stronger validators and earlier timing/neutral-ordering work. Its stronger checks retain the independent content findings; do not weaken them to force a passing release.

Do not apply this patch blindly to current main. Reconcile overlapping generators, timing/date logic, schema and guards. Claude owns recipe content and final regeneration. Generated unstaged output from that worktree is intentionally not included; regenerate only after integration review.
